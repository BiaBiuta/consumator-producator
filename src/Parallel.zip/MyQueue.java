import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MyQueue<T> {
    private final LinkedList<T> queue = new LinkedList<>();
    private final int MAX_CAPACITY = 100; // Can be set to 50 or 100 as required
    private final Lock queueLock = new ReentrantLock();
    private final Condition notFull = queueLock.newCondition();
    private final Condition notEmpty = queueLock.newCondition();
    private boolean producersFinished = false;

    public void enqueue(T element) throws InterruptedException {
        queueLock.lock();
        try {
            while (queue.size() >= MAX_CAPACITY) {
                notFull.await(); // Wait until the queue is not full
            }
            queue.add(element);
            notEmpty.signal(); // Notify that the queue is not empty
        } finally {
            queueLock.unlock();
        }
    }

    public T dequeue() throws InterruptedException {
        queueLock.lock();
        try {
            while (queue.isEmpty()) {
                notEmpty.await(); // Wait until there is something in the queue
            }
            T element = queue.remove();
            notFull.signal(); // Notify that the queue is not full
            return element;
        } finally {
            queueLock.unlock();
        }
    }

    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public void setProducersFinished() {
        queueLock.lock();
        try {
            producersFinished = true;
            notEmpty.signalAll(); // Wake up all waiting consumers
        } finally {
            queueLock.unlock();
        }
    }

    // This method allows consumers to check if producers are finished
    public boolean isProducersFinished() {
        return producersFinished;
    }
}
