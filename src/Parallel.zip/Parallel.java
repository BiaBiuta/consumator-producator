import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Parallel {
    public static void main(String[] args) throws IOException {
        MyList synchronizedList = new MyList();
        MyQueue<String> synchronizedQueue = new MyQueue<>();

        List<String> files = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= 10; j++) {
                files.add("C" + i + "_P" + j + ".txt");
            }
        }

        System.out.println(files);
        if (args.length < 2) {
            System.out.println("Must give P and p_r!");
        }
        int P = 16;
        int p_r = 4;
        int p_w = P - p_r;

        int start, end = 0, cat, rest;
        int N = files.size();
        start = 0;
        cat = N / p_r;
        rest = N % p_r;

        Lock lock = new ReentrantLock();
        Condition notFull = lock.newCondition();
        Condition notEmpty = lock.newCondition();

        Thread[] readers = new Thread[p_r];
        long start_t = System.nanoTime();

        for (int i = 0; i < p_r; i++) {
            end = start + cat;

            if (rest > 0) {
                end++;
                rest--;
            }

            readers[i] = new Producer(i + 1, start, end, synchronizedQueue, files, lock, notFull, notEmpty);
            start = end;

            readers[i].start();
        }

        Thread[] writers = new Thread[p_w];
        for (int i = 0; i < p_w; i++) {
            writers[i] = new Consumer(i + 1, synchronizedQueue, synchronizedList,lock, notFull, notEmpty);
            writers[i].start();
        }

        for (int i = 0; i < p_r; i++) {
            try {
                readers[i].join();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        synchronizedQueue.setProducersFinished();

        for (int i = 0; i < p_w; i++) {
            try {
                writers[i].join();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        //synchronizedList.showList();
        Utils.writeResult(synchronizedList, "ResultParallel.txt");
        long end_t = System.nanoTime();

       /* if (Utils.areFilesEqual("Result.txt", "resultParallel.txt")) {
            System.out.println("Files are equal!!!");
        } else {
            System.out.println("Files are not equal!!");
        }*/

        System.out.println((double) (end_t - start_t) / 1000000);
        System.out.println("P: " + P);
        System.out.println("p_r: " + p_r);
        System.out.println("p_w: " + p_w);
    }

    public static class Producer extends Thread {
        private static final Integer MAX_CAPACITY = 100;
        int id;
        int start;
        int end;
        MyQueue<String> queue;
        List<String> files;
        Lock lock;
        Condition notFull;
        Condition notEmpty;

        public Producer(int id, int start, int end, MyQueue<String> queue, List<String> files, Lock lock, Condition notFull, Condition notEmpty) {
            this.id = id;
            this.start = start;
            this.end = end;
            this.queue = queue;
            this.files = files;
            this.lock = lock;
            this.notFull = notFull;
            this.notEmpty = notEmpty;
        }

        public void readFromFileAddToQueue(String filePath) throws IOException, InterruptedException {
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    lock.lock();
                    try {
                        while (queue.size() == MAX_CAPACITY) {
                            System.out.println("Queue is full! " + "Producer #" + id + " is waiting...");
                            notFull.await();
                        }
                        queue.enqueue(line);
                        System.out.println("Producer #" + id + " added to queue: " + line);
                        notEmpty.signalAll(); // Notify consumers that queue is not empty
                    } finally {
                        lock.unlock();
                    }
                }
            }
        }

        public void run() {
            System.out.println("Producer #" + id + " start: " + start + " end: " + end + " reading ...");
            for (int i = start; i < end; i++) {
                String file = files.get(i);
                try {
                    readFromFileAddToQueue(file);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Producer #" + id + " done!!");
        }
    }


    public static class Consumer extends Thread {
        int id;
        MyQueue<String> queue;
        MyList list;
        Lock lock;
        Condition notFull;
        Condition notEmpty;

        public Consumer(int id, MyQueue<String> queue, MyList list, Lock lock, Condition notFull, Condition notEmpty) {
            this.id = id;
            this.queue = queue;
            this.list = list;
            this.lock = lock;
            this.notFull = notFull;
            this.notEmpty = notEmpty;
        }

        public void run() {
            try {
                while (true) {
                    lock.lock();
                    try {
                        // Wait while the queue is empty and producers are still working
                        while (queue.isEmpty() && !queue.isProducersFinished()) {
                            System.out.println("Consumer #" + id + " queue is empty. Waiting...");
                            notEmpty.await();
                        }

                        // Break the loop if the queue is empty and all producers have finished
                        if (queue.isEmpty() && queue.isProducersFinished()) {
                            System.out.println("Consumer #" + id + " finishing. Queue empty and no more producers.");
                            break;
                        }

                        // Dequeue and process an item
                        String line = queue.dequeue();
                        String[] parts = line.split(",");
                        int firstNumber = Integer.parseInt(parts[0].trim());
                        int secondNumber = Integer.parseInt(parts[1].trim());
                        list.addNode(firstNumber, secondNumber);
                        System.out.println("Consumer #" + id + " added to list");

                        // Signal that there's now space in the queue
                        notFull.signal();
                    } finally {
                        lock.unlock();
                    }
                }
            } catch (InterruptedException e) {
                System.out.println("Consumer #" + id + " interrupted.");
            } finally {
                System.out.println("Consumer #" + id + " exiting.");
            }
        }

    }
}