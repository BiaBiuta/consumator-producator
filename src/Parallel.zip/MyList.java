import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyList {
    private final Node head; // Sentinel start node
    private final Node tail; // Sentinel end node
    private final Map<Integer, Node> frauds;

    public MyList(){
        head = new Node();
        tail = new Node();
        head.setNext(tail); // Initially, head points directly to tail
        frauds = new HashMap<>();
    }

    public void addNode(int idP, int score) {
        Node newNode = new Node(idP, score);
        head.lock(); // Lock the head sentinel node
        Node prev = head;
        Node curr = head.getNext();
        curr.lock(); // Lock the first real node

        try {
            while (curr != tail && curr.getScore() <= newNode.getScore()) {
                prev.unlock();
                prev = curr;
                curr = curr.getNext();
                curr.lock();
            }

            // Insert the new node
            newNode.setNext(curr);
            prev.setNext(newNode);

            if (newNode.getScore() == -1) {
                frauds.put(idP, newNode);
                deleteNode(newNode.getIdP());
            }

            Node foundN = find(newNode.getIdP());
            if (foundN != null) {
                newNode.setScore(newNode.getScore() + foundN.getScore());
                deleteNode(newNode.getIdP());
            }
        } finally {
            prev.unlock();
            curr.unlock();
        }
    }

    public void deleteNode(int idP) {
        head.lock();
        Node prev = head;
        Node curr = head.getNext();
        curr.lock();

        try {
            while (curr != tail && curr.getIdP() != idP) {
                prev.unlock();
                prev = curr;
                curr = curr.getNext();
                curr.lock();
            }

            if (curr != tail) {
                prev.setNext(curr.getNext());
            }
        } finally {
            prev.unlock();
            curr.unlock();
        }
    }

    public Node find(int idP) {
        head.lock();
        Node prev = head;
        Node curr = head.getNext();
        curr.lock();

        try {
            while (curr != tail && curr.getIdP() != idP) {
                prev.unlock();
                prev = curr;
                curr = curr.getNext();
                curr.lock();
            }

            return curr != tail ? curr : null;
        } finally {
            prev.unlock();
            curr.unlock();
        }
    }

    public boolean isFraud(int idP) {
        return frauds.containsKey(idP);
    }

    public List<Node> getElements(){
        List<Node> all = new ArrayList<>();
        Node p = this.head;
        while(p!=null){
            all.add(p);
            p = p.getNext();
        }
        return all;
    }
}
